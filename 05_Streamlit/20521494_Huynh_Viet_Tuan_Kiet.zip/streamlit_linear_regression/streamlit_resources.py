from PIL import Image

is_loaded = False
is_train = False
icon_check_success = Image.open('./images/check.png')
image_header = Image.open('./images/image_introduce.png')
icon_warning = Image.open('./images/warning.png')